package com.example.seguimiento2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import com.example.seguimiento2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configurar el Drawer (Panel lateral)
        val toggle = ActionBarDrawerToggle(this, binding.drawerLayout, 0, 0)
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Lógica del Menú Lateral
        binding.navView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_conversor -> ejecutarCargaYAbrir()
                R.id.nav_home -> Toast.makeText(this, "Ya estás en Inicio", Toast.LENGTH_SHORT).show()
            }
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
    }

    private fun ejecutarCargaYAbrir() {
        binding.progressBarMain.visibility = View.VISIBLE

        Thread {
            for (i in 1..100) {
                Thread.sleep(15)
                runOnUiThread { binding.progressBarMain.progress = i }
            }
            runOnUiThread {
                Toast.makeText(this, "Carga completa", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity2::class.java))
                binding.progressBarMain.visibility = View.GONE
            }
        }.start()
    }

    override fun onSupportNavigateUp(): Boolean {
        binding.drawerLayout.openDrawer(GravityCompat.START)
        return true
    }
}