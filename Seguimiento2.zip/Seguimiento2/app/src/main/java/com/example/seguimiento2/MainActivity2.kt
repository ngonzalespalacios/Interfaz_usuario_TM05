package com.example.seguimiento2

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.seguimiento2.databinding.ActivityMain2Binding

class MainActivity2 : AppCompatActivity() {

    private lateinit var binding: ActivityMain2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCalcular.setOnClickListener {
            val solesStr = binding.etSoles.text.toString()
            if (solesStr.isNotEmpty()) {
                iniciarProceso(solesStr.toDouble())
            }
        }
    }

    private fun iniciarProceso(monto: Double) {
        binding.progressBarSec.visibility = View.VISIBLE
        binding.tvMensajeCarga.visibility = View.GONE

        Thread {
            for (i in 1..100) {
                Thread.sleep(10)
                runOnUiThread { binding.progressBarSec.progress = i }
            }
            runOnUiThread {
                val dolares = monto / 3.75 // Tasa de cambio ejemplo
                binding.tvResultado.text = "USD: $${String.format("%.2f", dolares)}"

                // REQUISITO: Mensaje de carga completa
                binding.tvMensajeCarga.text = "Carga completa"
                binding.tvMensajeCarga.visibility = View.VISIBLE
                binding.progressBarSec.visibility = View.INVISIBLE
            }
        }.start()
    }
}